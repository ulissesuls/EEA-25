the ice40lp1k-cm36 actually has no PLL check the datasheet for detail.
FPGA-TN-02052-1-2-iCE40-sysCLOCK-PLL-Design-Usage-Guide.pdf
