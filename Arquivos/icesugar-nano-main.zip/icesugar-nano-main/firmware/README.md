this 128KB firmware include usb-hid & usb-cdc device
